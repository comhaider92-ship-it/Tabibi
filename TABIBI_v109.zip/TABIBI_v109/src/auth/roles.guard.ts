import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ROLES_KEY } from './roles.decorator';
import { UserRole } from '../users/user.entity';
@Injectable()
export class RolesGuard implements CanActivate {
 constructor(private readonly reflector:Reflector){}
 canActivate(ctx:ExecutionContext):boolean {
  const roles=this.reflector.getAllAndOverride<UserRole[]>(ROLES_KEY,[ctx.getHandler(),ctx.getClass()]);
  if(!roles?.length) return true;
  const user=ctx.switchToHttp().getRequest().user;
  return !!user && roles.includes(user.role);
 }
}
